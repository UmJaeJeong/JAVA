package sec_verify01;

public class Car 
{
	String model;
	int door;
	
	public Car(String model, int door)
	{
		this.model = model;
		this.door = door;		
	}
}
